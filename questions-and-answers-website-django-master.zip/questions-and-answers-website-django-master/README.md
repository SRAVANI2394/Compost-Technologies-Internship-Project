# How to create a Q&A website using Django Python | Django portfolio website

Find full tutorial here 👉 [Youtube](https://youtu.be/PR9Ws30iIU8)

Hello everyone, in this video we build a Q&A website using Django, you'll learn a lot of the basic stuff to help you started in your own projects. The idea of this project is that you can use it to create your own version of this project and add that to your portfolio.

This video cover these topics:
- Django forms
- Django templates
- Django Models & Django databases
- Django QuerySet
- Django ORM
- Relationships in Django
- Django authentication

Follow me:
https://www.instagram.com/codingvenue/
